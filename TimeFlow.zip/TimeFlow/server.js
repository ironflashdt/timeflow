/* ============================================================================
   TimeFlow — serveur local (Node natif, zéro dépendance)
   - OAuth Google + Google Calendar (lecture/écriture)
   - IA locale gratuite via Ollama
   - Moteur de planification : Focus, Habitudes, Tâches (avec découpage),
     Buffers, priorités P1-P4, heures perso/pro, time defense, no-meeting days
   - Replanification auto quand l'agenda change
   Lancer :  node server.js   →   http://localhost:3000
============================================================================ */

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');

const PORT        = 3000;
const TOKEN_FILE  = path.join(__dirname, 'tokens.json');
const CONFIG_FILE = path.join(__dirname, 'config.json');
const HABITS_FILE = path.join(__dirname, 'habits.json');
const TASKS_FILE  = path.join(__dirname, 'tasks.json');
const STATS_FILE  = path.join(__dirname, 'stats.json');
const MEMORY_FILE = path.join(__dirname, 'memory.json');

// ─── CONFIG (valeurs par défaut, fusionnées avec config.json) ───
const DEFAULT_HOURS = on => ({ mon:{on:true,start:9,end:18}, tue:{on:true,start:9,end:18}, wed:{on:true,start:9,end:18}, thu:{on:true,start:9,end:18}, fri:{on:true,start:9,end:18}, sat:{on:false,start:10,end:16}, sun:{on:false,start:10,end:16} });
let config = {
  client_id:'', client_secret:'',
  ollama_url:'http://127.0.0.1:11434', model:'llama3.1:8b',
  timezone:'Europe/Paris',
  work_start:9, work_end:18,          // heures de travail (focus + tâches)
  personal_start:7, personal_end:22,  // heures perso (habitudes par défaut)
  focus_duration:120, buffer_minutes:15,
  no_meeting_days:[],                 // ex: ["mercredi"]
  auto_schedule:true,
  // ── Moteur type Reclaim ──
  task_max_per_day:240, focus_weekly_target:0, focus_max_per_day:180, horizon_days:14,
  // ── Compte / profil ──
  profile:{ name:'', company:'', company_size:'', job_title:'', department:'', role:'', usage:'' },
  start_week_on:'monday',            // 'monday' | 'sunday'
  // ── Horaires détaillés (par jour) ──
  working_hours: DEFAULT_HOURS(), personal_hours:{ mon:{on:true,start:7,end:22}, tue:{on:true,start:7,end:22}, wed:{on:true,start:7,end:22}, thu:{on:true,start:7,end:22}, fri:{on:true,start:7,end:22}, sat:{on:true,start:8,end:23}, sun:{on:true,start:8,end:23} },
  meeting_hours: DEFAULT_HOURS(),
  // ── Marges (buffers) ──
  buffers:{ task_habit_break:0, travel_time:0, decompression:0 },
  // ── Couleurs (catégorie → colorId Google) ──
  colors:{ team_meeting:'9', work:'2', personal:'6', travel_breaks:'8', external_meeting:'7', one_on_one:'1', focus:'2' },
  color_scope:'managed',             // 'managed' | 'all'
  // ── Planification (affichage + comportement) ──
  date_format:'DD/MM/YYYY', time_format:'24h', auto_lock:false, start_intervals:15,
  emoji_prefix:false, calendar_tips:true,
  auto_reflow:true,                  // réorganise tout après une modif manuelle
  focus_mode:'proactive',            // 'proactive' | 'reactive'
  timeoff:[],                        // [{start:'YYYY-MM-DD',end:'YYYY-MM-DD',label}] congés/absences
  // ── Valeurs par défaut des tâches ──
  task_defaults:{ priority:'p2', duration:60, split:true, min_chunk:30, max_chunk:120, hours:'work', start_delay_h:0, due_days:3, private:true, oneoff_duration:30 },
  // ── Notifications (navigateur) ──
  notif:{ desktop:false, chime:false, tab_alert:true, reminder_min:5, daily_summary:false }
};
// fusion (deep-merge des objets imbriqués connus)
if (fs.existsSync(CONFIG_FILE)) {
  const saved = JSON.parse(fs.readFileSync(CONFIG_FILE));
  const NEST = ['profile','working_hours','personal_hours','meeting_hours','buffers','colors','task_defaults','notif'];
  for (const k of NEST) if (saved[k] && typeof saved[k]==='object') saved[k] = {...config[k], ...saved[k]};
  config = {...config, ...saved};
}
function saveConfig(){ fs.writeFileSync(CONFIG_FILE, JSON.stringify(config)); }

// ─── DONNÉES ───
let tokens = fs.existsSync(TOKEN_FILE) ? JSON.parse(fs.readFileSync(TOKEN_FILE)) : null;
let habits = fs.existsSync(HABITS_FILE) ? JSON.parse(fs.readFileSync(HABITS_FILE)) : [];
let tasks  = fs.existsSync(TASKS_FILE)  ? JSON.parse(fs.readFileSync(TASKS_FILE))  : [];
let stats  = fs.existsSync(STATS_FILE)  ? JSON.parse(fs.readFileSync(STATS_FILE))  : { focusHours:0, meetingHours:0, habitsCompleted:0, streak:0 };

const DEFAULT_MEMORY = { goals:[], constraints:[], preferences:[], weekHistory:[], lastPlanHash:'' };
let memory = fs.existsSync(MEMORY_FILE) ? {...DEFAULT_MEMORY, ...JSON.parse(fs.readFileSync(MEMORY_FILE))} : {...DEFAULT_MEMORY};
function saveMemory(){ fs.writeFileSync(MEMORY_FILE, JSON.stringify(memory, null, 2)); }

const saveHabits = () => fs.writeFileSync(HABITS_FILE, JSON.stringify(habits));
const saveTasks  = () => fs.writeFileSync(TASKS_FILE,  JSON.stringify(tasks));
const saveStats  = () => fs.writeFileSync(STATS_FILE,  JSON.stringify(stats));

// ─── VERROUS (événements épinglés manuellement → le moteur ne les déplace pas) ───
const LOCKS_FILE = path.join(__dirname, 'locks.json');
let locks = new Set(fs.existsSync(LOCKS_FILE) ? JSON.parse(fs.readFileSync(LOCKS_FILE)) : []);
const saveLocks = () => fs.writeFileSync(LOCKS_FILE, JSON.stringify([...locks]));

// ─── ÉTAT POLLING CALENDRIER ───
let lastCalendarHash = '';
let replanDebounce   = null;

// ─── OAUTH ───
const REDIRECT_URI = `http://localhost:${PORT}/oauth/callback`;
const SCOPES = 'https://www.googleapis.com/auth/calendar';

/* ───────────────────────────────────────────────────────────────
   IDENTIFIANTS GOOGLE OAUTH  (à remplir UNE seule fois)
   ───────────────────────────────────────────────────────────────
   Colle ici les identifiants de TON projet Google Cloud :
     • API « Google Calendar » activée
     • Écran de consentement OAuth configuré
     • URI de redirection autorisée : http://localhost:3000/oauth/callback
   Une fois ces deux valeurs renseignées, l'app affiche directement
   « Continuer avec Google » dès le premier lancement et connecte
   l'agenda automatiquement après la connexion.
   (Si tu utilises déjà l'app, tu retrouves ces valeurs dans config.json.)
   Laisse vide pour conserver l'ancien mode « saisie manuelle ».
*/
const GOOGLE_CLIENT_ID     = ''; // ex : 1234567890-abcd….apps.googleusercontent.com
const GOOGLE_CLIENT_SECRET = ''; // ex : GOCSPX-xxxxxxxxxxxxxxxxxxxx

// Un identifiant saisi manuellement (config.json) a priorité ; sinon on prend l'intégré.
const clientId     = () => config.client_id     || GOOGLE_CLIENT_ID;
const clientSecret = () => config.client_secret || GOOGLE_CLIENT_SECRET;
const hasCreds     = () => !!(clientId() && clientSecret());

function getAuthUrl() {
  const p = new URLSearchParams({
    client_id:clientId(), redirect_uri:REDIRECT_URI, response_type:'code',
    scope:SCOPES, access_type:'offline', prompt:'consent'
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${p}`;
}

function oauthPost(body) {
  return new Promise((resolve, reject) => {
    const b = JSON.stringify(body);
    const req = https.request({ hostname:'oauth2.googleapis.com', path:'/token', method:'POST',
      headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(b)} },
      res => { let d=''; res.on('data',c=>d+=c); res.on('end',()=>{ try{resolve(JSON.parse(d));}catch{resolve({});} }); });
    req.on('error',reject); req.write(b); req.end();
  });
}

async function refreshAccessToken() {
  const t = await oauthPost({ client_id:clientId(), client_secret:clientSecret(), refresh_token:tokens.refresh_token, grant_type:'refresh_token' });
  if (!t.access_token) throw new Error('Refresh token invalide — reconnecte-toi.');
  tokens.access_token = t.access_token;
  tokens.expiry_date  = Date.now() + (t.expires_in * 1000);
  fs.writeFileSync(TOKEN_FILE, JSON.stringify(tokens));
}

async function getValidToken() {
  if (!tokens) throw new Error('Non authentifié');
  if (tokens.expiry_date && Date.now() > tokens.expiry_date - 60000) await refreshAccessToken();
  return tokens.access_token;
}

// ─── GOOGLE CALENDAR ───
function calReq(method, urlPath, body=null) {
  return getValidToken().then(token => new Promise((resolve, reject) => {
    const bs = body ? JSON.stringify(body) : null;
    const headers = { 'Authorization':`Bearer ${token}`, 'Content-Type':'application/json' };
    if (bs) headers['Content-Length'] = Buffer.byteLength(bs);
    const req = https.request({ hostname:'www.googleapis.com', path:urlPath, method, headers }, res => {
      let d=''; res.on('data',c=>d+=c); res.on('end',()=>{ try{resolve({status:res.statusCode,data:d?JSON.parse(d):{}});}catch{resolve({status:res.statusCode,data:{}});} });
    });
    req.on('error',reject); if (bs) req.write(bs); req.end();
  }));
}

async function getEvents(timeMin, timeMax) {
  const p = new URLSearchParams({
    timeMin: timeMin || new Date().toISOString(),
    timeMax: timeMax || new Date(Date.now()+7*86400000).toISOString(),
    singleEvents:'true', orderBy:'startTime', maxResults:'250'
  });
  const r = await calReq('GET', `/calendar/v3/calendars/primary/events?${p}`);
  return r.data.items || [];
}

async function createEvent(ev) {
  const b = {
    summary: ev.title, description: ev.description || 'TimeFlow',
    colorId: ev.colorId || '9',
    start: { dateTime:ev.start, timeZone:config.timezone },
    end:   { dateTime:ev.end,   timeZone:config.timezone }
  };
  if (ev.extendedProperties) b.extendedProperties = ev.extendedProperties;
  if (ev.transparency)       b.transparency = ev.transparency;          // 'transparent' = Disponible
  if (ev.location)           b.location = ev.location;
  const r = await calReq('POST', '/calendar/v3/calendars/primary/events', b);
  return r.data;
}

async function updateEvent(id, ev) {
  const body = {};
  if (ev.title!=null) body.summary = ev.title;
  if (ev.description!=null) body.description = ev.description;
  if (ev.start) body.start = { dateTime:ev.start, timeZone:config.timezone };
  if (ev.end)   body.end   = { dateTime:ev.end,   timeZone:config.timezone };
  if (ev.colorId) body.colorId = ev.colorId;
  if (ev.extendedProperties) body.extendedProperties = ev.extendedProperties;
  if (ev.transparency) body.transparency = ev.transparency;
  if (ev.location!=null) body.location = ev.location;
  const r = await calReq('PATCH', `/calendar/v3/calendars/primary/events/${id}`, body);
  return r.data;
}

async function getEvent(id) {
  const r = await calReq('GET', `/calendar/v3/calendars/primary/events/${id}`);
  return r.data;
}

async function deleteEvent(id) {
  const r = await calReq('DELETE', `/calendar/v3/calendars/primary/events/${id}`);
  return r.status === 204 || r.status === 200 || r.status === 410;
}

// ─── OLLAMA (IA locale gratuite) ───
function ollamaCall(messages, systemPrompt, jsonMode=false) {
  return new Promise((resolve, reject) => {
    const u = new URL(config.ollama_url || 'http://127.0.0.1:11434');
    const body = JSON.stringify({
      model: config.model || 'llama3.1:8b',
      messages: [{ role:'system', content:systemPrompt }, ...messages],
      stream: false, options:{ temperature:0.4 },
      ...(jsonMode ? { format:'json' } : {})
    });
    const req = http.request({ hostname:u.hostname, port:u.port||11434, path:'/api/chat', method:'POST',
      headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)} },
      res => { let d=''; res.on('data',c=>d+=c); res.on('end',()=>{ try{resolve(JSON.parse(d));}catch(e){reject(e);} }); });
    req.on('error',reject); req.write(body); req.end();
  });
}

// ─── HELPERS PLANIFICATION ───
const DAY_MAP = { dimanche:0, lundi:1, mardi:2, mercredi:3, jeudi:4, vendredi:5, samedi:6 };
const PRIO_RANK = { p1:0, critical:0, p2:1, high:1, p3:2, medium:2, p4:3, low:3 };
const prioRank  = p => PRIO_RANK[String(p||'medium').toLowerCase()] ?? 2;
const PRIO_DOT  = ['🔴','🟠','🟡','🟢'];
const PRIO_COLOR= ['11','6','5','2'];   // Google colorIds: tomato, tangerine, banana, sage

// Créneaux libres d'une journée entre [startH, endH], durée min en minutes
function getFreeSlots(events, date, startH, endH, minDuration=30) {
  const slots = [];
  const dS = new Date(date); dS.setHours(startH,0,0,0);
  const dE = new Date(date); dE.setHours(endH,0,0,0);
  const busy = events
    .filter(e => { const s=new Date(e.start?.dateTime||e.start?.date); const en=new Date(e.end?.dateTime||e.end?.date); return en>dS && s<dE; })
    .map(e => ({ start:new Date(e.start?.dateTime||e.start?.date), end:new Date(e.end?.dateTime||e.end?.date) }))
    .sort((a,b)=>a.start-b.start);
  let cur = new Date(dS);
  for (const b of busy) {
    if (cur < b.start) { const dur=(b.start-cur)/60000; if (dur>=minDuration) slots.push({start:new Date(cur),end:new Date(b.start),duration:dur}); }
    if (b.end > cur) cur = new Date(b.end);
  }
  if (cur < dE) { const dur=(dE-cur)/60000; if (dur>=minDuration) slots.push({start:new Date(cur),end:new Date(dE),duration:dur}); }
  return slots;
}

// ISO avec le BON décalage horaire (gère l'heure d'été automatiquement)
function isoLocal(date) {
  const d = new Date(date);
  const pad = n => String(n).padStart(2,'0');
  const off = -d.getTimezoneOffset();              // minutes à l'est de UTC
  const sign = off >= 0 ? '+' : '-';
  const a = Math.abs(off);
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:00${sign}${pad(Math.floor(a/60))}:${pad(a%60)}`;
}

function buildEventsHash(events) {
  return events.map(e=>`${e.id}|${e.start?.dateTime}|${e.end?.dateTime}`).sort().join(';');
}
const tfManaged = e => e.extendedProperties?.private?.tfManaged === '1';
const isManaged = e => tfManaged(e) || e.summary?.includes('🎯') || e.summary?.includes('⏸️') ||
  PRIO_DOT.some(d=>e.summary?.startsWith(d)) || habits.some(h=>h.name && e.summary?.includes(h.name));
const isLocked  = e => locks.has(e.id) || e.extendedProperties?.private?.tfLocked === '1';
const tfKindOf  = e => e.extendedProperties?.private?.tfKind || (e.summary?.includes('🎯')?'focus':(e.summary?.includes('⏸️')?'buffer':(habits.some(h=>h.name&&e.summary?.includes(h.name))?'habit':'task')));

const sameDay = (a,b) => new Date(a).toDateString() === new Date(b).toDateString();
const eventsOfDay = (events, day) => events.filter(e => sameDay(e.start?.dateTime||e.start?.date, day));
const snoozed = x => x.snoozeUntil && new Date(x.snoozeUntil) > new Date();
const blockedDay = dayLow => (config.no_meeting_days||[]).map(s=>s.toLowerCase()).includes(dayLow)
  || memory.constraints.some(c => { const t=c.text.toLowerCase(); return t.includes(dayLow) && /(pas|jamais|no )/.test(t); });

// ─── MÉMOIRE (contexte pour l'IA) ───
function buildMemoryContext() {
  const L = [];
  if (memory.goals.length)       L.push('OBJECTIFS:\n'+memory.goals.map(g=>`- ${g.text}`).join('\n'));
  if (memory.constraints.length) L.push('CONTRAINTES:\n'+memory.constraints.map(c=>`- ${c.text}`).join('\n'));
  if (memory.preferences.length) L.push('PRÉFÉRENCES:\n'+memory.preferences.map(p=>`- ${p.text}`).join('\n'));
  if (memory.weekHistory.length) L.push('HISTORIQUE RÉCENT:\n'+memory.weekHistory.slice(-3).map(w=>`- Semaine du ${w.weekOf}: ${w.summary}`).join('\n'));
  return L.join('\n\n');
}

// ─── CHAT IA ───
async function processChat(userMessage, chatHistory, currentEvents) {
  const today = new Date();
  const todayStr = today.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  const todayISO = today.toISOString().split('T')[0];
  const memCtx = buildMemoryContext();
  const evCtx = currentEvents.length
    ? currentEvents.map(e=>`ID:${e.id}|"${e.summary||'Sans titre'}"|${e.start?.dateTime||e.start?.date}→${e.end?.dateTime||e.end?.date}`).join('\n')
    : 'Aucun événement.';

  const cfgSummary = `Travail ${config.work_start}h-${config.work_end}h · Perso ${config.personal_start}h-${config.personal_end}h · Focus ${config.focus_weekly_target}h/sem (${config.focus_mode}) · Réorg auto ${config.auto_reflow!==false?'oui':'non'} · Congés: ${(config.timeoff||[]).map(t=>t.start+'→'+t.end).join(', ')||'aucun'}`;

  const intentSystem = `Tu es l'assistant de TimeFlow, un agenda intelligent. Aujourd'hui: ${todayStr} (${todayISO}). Fuseau ${config.timezone}.
Tu peux TOUT piloter : événements, habitudes, tâches, priorités, réglages, congés, et réorganiser le planning.
Réponds UNIQUEMENT en JSON valide (aucun markdown, aucun texte autour).

Contexte utilisateur:
${memCtx || 'Aucun.'}
Réglages: ${cfgSummary}
Habitudes: ${habits.map(h=>`#${h.id}|${h.name}|${h.priority||'p3'}`).join(' ; ')||'aucune'}
Tâches: ${tasks.map(t=>`#${t.id}|${t.title}|${t.priority||'p2'}${t.deadline?'|échéance '+t.deadline:''}`).join(' ; ')||'aucune'}
Événements (ID|titre|début→fin):
${evCtx}

Renseigne UNIQUEMENT les blocs utiles (laisse null le reste) :
{
 "event": {"op":"create|update|delete","title":"","start":"${todayISO}T09:00:00","end":"${todayISO}T10:00:00","eventId":""} | null,
 "habit": {"op":"add|update|delete","id":"","name":"","emoji":"","priority":"p3","hoursType":"personal","idealDays":["lundi","mercredi"],"idealDay":"","idealTime":"18:00","minDur":45,"maxDur":60,"timesPerWeek":3,"startDate":"","endDate":""} | null,
 "task": {"op":"add|update|delete","id":"","title":"","duration":60,"priority":"p2","deadline":"${todayISO}","upNext":false,"hoursType":"work"} | null,
 "priority": {"kind":"habit|task","name":"","priority":"p1"} | null,
 "config": {"work_start":9,"work_end":18,"focus_weekly_target":5,"focus_mode":"reactive","auto_reflow":true,"no_meeting_days":["mercredi"]} | null,
 "timeoff": {"start":"YYYY-MM-DD","end":"YYYY-MM-DD","label":"Congés"} | null,
 "optimize": false,
 "memory": {"goals":[],"constraints":[],"preferences":[]}
}
Règles :
- "demain"=${todayISO}+1j ; "ce soir"=aujourd'hui 19h.
- Activité récurrente (chaque semaine) -> habit (jours en français). Tâche ponctuelle avec échéance -> task.
- "je suis en vacances/congés du X au Y", "je pars en voyage" -> timeoff + optimize:true.
- "mets/passe le sport en critique/P1" -> priority.
- "change mes heures de travail / objectif focus / jours sans réunion / coupe les notifs" -> config.
- "réorganise/optimise/replanifie mon planning" -> optimize:true.
- Objectif de vie -> memory.goals ; contrainte -> memory.constraints ; préférence de planning -> memory.preferences.`;

  let intent = {};
  try {
    const r = await ollamaCall([{role:'user',content:userMessage}], intentSystem, true);
    intent = JSON.parse((r.message?.content||'{}').replace(/```json|```/g,'').trim());
  } catch(e){ console.error('Intent fail:', e.message); }

  const applied=[]; let memChanged=false, structural=false, actionError=null;
  const findByName=(arr,name)=>{ if(!name) return null; const n=String(name).toLowerCase(); return arr.find(x=>String(x.name||x.title||'').toLowerCase()===n) || arr.find(x=>String(x.name||x.title||'').toLowerCase().includes(n)); };

  // Mémoire
  const mem=intent.memory||{};
  ['goals','constraints','preferences'].forEach(k=>{ (mem[k]||[]).forEach(txt=>{ if(txt && !memory[k].find(x=>x.text===txt)){ memory[k].push({id:Date.now()+''+Math.random(),text:txt,addedAt:new Date().toISOString()}); memChanged=true; applied.push('Mémoire : '+txt); } }); });

  try {
    // ÉVÉNEMENT (fixe, sans chevauchement, créneau déduit du titre)
    if (intent.event && intent.event.op){
      const ev=intent.event;
      if (ev.op==='create' && ev.title && ev.start && ev.end){
        const slot=placeNoOverlap(ev.start, ev.end, currentEvents, inferWindow(ev.title));
        const c=await createEvent({title:ev.title, start:slot.start, end:slot.end});
        applied.push('Événement créé : '+ev.title+(slot.shifted?' (déplacé pour éviter un chevauchement)':'')+(slot.conflict?' (créneau libre introuvable)':''));
      } else if (ev.op==='update' && ev.eventId){
        let st=ev.start, en=ev.end;
        if (st&&en){ const slot=placeNoOverlap(st,en,currentEvents.filter(x=>x.id!==ev.eventId), ev.title?inferWindow(ev.title):null); st=slot.start; en=slot.end; }
        const u=await updateEvent(ev.eventId,{title:ev.title,start:st,end:en}); applied.push('Événement modifié : '+(ev.title||u.summary||''));
      } else if (ev.op==='delete' && ev.eventId){ if(await deleteEvent(ev.eventId)){ locks.delete(ev.eventId); saveLocks(); applied.push('Événement supprimé'); } }
    }
    // HABITUDE
    if (intent.habit && intent.habit.op){
      const h=intent.habit;
      if (h.op==='add' && h.name){
        const maxD=h.maxDur||h.minDur||60, minD=h.minDur||maxD; const days=h.idealDays||h.days||[];
        habits.push({id:Date.now()+'',active:true,name:h.name,emoji:h.emoji||'',priority:h.priority||'p3',hoursType:h.hoursType||'personal',idealDays:days,idealDay:h.idealDay||'',idealTime:h.idealTime||'18:00',minDur:minD,maxDur:maxD,timesPerWeek:h.timesPerWeek||days.length||1,startDate:h.startDate||'',endDate:h.endDate||'',days,duration:maxD});
        saveHabits(); structural=true; applied.push('Habitude créée : '+h.name);
      } else if (h.op==='update'){ const tgt=h.id?habits.find(x=>x.id===h.id):findByName(habits,h.name); if(tgt){ Object.keys(h).forEach(k=>{ if(['op','id'].includes(k))return; if(h[k]!=null&&h[k]!=='') tgt[k]=h[k]; }); if(h.maxDur) tgt.duration=h.maxDur; saveHabits(); structural=true; applied.push('Habitude modifiée : '+tgt.name); } }
      else if (h.op==='delete'){ const tgt=h.id?habits.find(x=>x.id===h.id):findByName(habits,h.name); if(tgt){ habits=habits.filter(x=>x!==tgt); saveHabits(); structural=true; applied.push('Habitude supprimée : '+tgt.name); } }
    }
    // TÂCHE
    if (intent.task && intent.task.op){
      const t=intent.task;
      if (t.op==='add' && t.title){ tasks.push({id:Date.now()+'',active:true,scheduled:false,title:t.title,duration:t.duration||60,priority:t.priority||'p2',deadline:t.deadline||'',upNext:!!t.upNext,hoursType:t.hoursType||'work',splitUp:true,minChunk:30,maxChunk:120}); saveTasks(); structural=true; applied.push('Tâche créée : '+t.title); }
      else if (t.op==='update'){ const tgt=t.id?tasks.find(x=>x.id===t.id):findByName(tasks,t.title); if(tgt){ Object.keys(t).forEach(k=>{ if(['op','id'].includes(k))return; if(t[k]!=null&&t[k]!=='') tgt[k]=t[k]; }); tgt.scheduled=false; delete tgt.eventIds; saveTasks(); structural=true; applied.push('Tâche modifiée : '+tgt.title); } }
      else if (t.op==='delete'){ const tgt=t.id?tasks.find(x=>x.id===t.id):findByName(tasks,t.title); if(tgt){ tasks=tasks.filter(x=>x!==tgt); saveTasks(); structural=true; applied.push('Tâche supprimée : '+tgt.title); } }
    }
    // PRIORITÉ
    if (intent.priority && intent.priority.priority){
      const p=intent.priority; const arr=p.kind==='task'?tasks:habits; const tgt=findByName(arr,p.name);
      if(tgt){ tgt.priority=p.priority; tgt.scheduled=false; if(p.kind==='task') saveTasks(); else saveHabits(); structural=true; applied.push('Priorité ('+(tgt.name||tgt.title)+') -> '+String(p.priority).toUpperCase()); }
    }
    // RÉGLAGES (liste blanche)
    if (intent.config && typeof intent.config==='object'){
      const WL=['work_start','work_end','personal_start','personal_end','focus_duration','focus_weekly_target','focus_max_per_day','focus_mode','task_max_per_day','horizon_days','auto_reflow','auto_lock','no_meeting_days','buffers','working_hours','personal_hours','meeting_hours','time_format','start_week_on','emoji_prefix'];
      const patch={}; Object.keys(intent.config).forEach(k=>{ if(WL.includes(k)) patch[k]=intent.config[k]; });
      ['buffers','working_hours','personal_hours','meeting_hours'].forEach(k=>{ if(patch[k]&&typeof patch[k]==='object') patch[k]={...config[k],...patch[k]}; });
      if(Object.keys(patch).length){ config={...config,...patch}; saveConfig(); structural=true; applied.push('Réglages mis à jour : '+Object.keys(patch).join(', ')); }
    }
    // CONGÉS / VACANCES
    if (intent.timeoff && intent.timeoff.start && intent.timeoff.end){
      const to=intent.timeoff; config.timeoff=[...(config.timeoff||[]),{start:to.start,end:to.end,label:to.label||'Congés'}]; saveConfig();
      structural=true; applied.push('Congés enregistrés : '+to.start+' -> '+to.end+' (aucun travail planifié, habitudes perso conservées)');
    }
  } catch(e){ actionError=e.message; }
  if (memChanged) saveMemory();

  // Réorganisation automatique du planning
  let risks=[]; let reorganized=false;
  if ((structural || intent.optimize===true) && tokens && config.auto_reflow!==false){
    try{ const ro=await optimize({days:config.horizon_days||14}); risks=ro.risks||[]; reorganized=true; applied.push('Planning réorganisé autour de vos contraintes'); }catch(e){ actionError=actionError||e.message; }
  }

  const respSystem = `Tu es TimeFlow, assistant planning. Réponds TOUJOURS en français, 2 à 4 phrases, clair et chaleureux. Aujourd'hui ${todayStr}.
${memCtx ? 'Contexte:\n'+memCtx : ''}
${applied.length ? 'Actions réalisées:\n- '+applied.join('\n- ') : "Aucune action structurelle (réponds à la demande / pose une question si besoin)."}
${risks.length ? "Tâches à risque d'échéance : "+risks.map(r=>r.title+' ('+r.missing+' min non placés)').join(' ; ') : ''}
${actionError ? 'Erreur technique : '+actionError : ''}
Confirme clairement ce qui a été fait et propose une suite utile si pertinent. N'invente pas d'action non listée.`;

  const r2 = await ollamaCall([...chatHistory, {role:'user',content:userMessage}], respSystem, false);
  return {
    response: r2.message?.content || 'OK.',
    action: applied.length ? { type:'multi', applied } : null,
    error: actionError, memoryUpdated: memChanged, risks, reload: reorganized || structural,
    memorySnapshot: { goals:memory.goals, constraints:memory.constraints, preferences:memory.preferences }
  };
}

// ─── MOTEUR DE PLANIFICATION (type Reclaim : contraintes + priorités) ───
// Pas d'IA : un solveur glouton à scoring. Ordre strict P1→P4 ; à priorité égale,
// habitudes avant tâches (comme Reclaim). Les blocs gérés non verrouillés sont
// recalculés ; les événements réels + blocs verrouillés sont immuables.
const pad2 = n => String(n).padStart(2,'0');
function startOfToday(){ const d=new Date(); d.setHours(0,0,0,0); return d; }
function hoursWindow(type){ return type==='personal' ? [config.personal_start??7, config.personal_end??22] : [config.work_start??9, config.work_end??18]; }
// Heures par jour (0=dim..6=sam) → [start,end] ou null si jour désactivé
const HK = ['sun','mon','tue','wed','thu','fri','sat'];
function dayHours(type, wd){
  const map = type==='personal'?config.personal_hours : type==='meeting'?config.meeting_hours : config.working_hours;
  const d = map && map[HK[wd]];
  if(d){ if(d.on===false) return null; return [d.start, d.end]; }
  return hoursWindow(type);
}
function dayKey(wd){ return Object.keys(DAY_MAP).find(k=>DAY_MAP[k]===wd); }
function gapMin(){ return (config.buffers?.task_habit_break ?? config.buffer_minutes) || 0; }
function snapStep(){ return config.start_intervals || 5; }
function roundUp5(d){ const ms=snapStep()*60000; return new Date(Math.ceil(d.getTime()/ms)*ms); }
function emo(e){ return config.emoji_prefix===false ? '' : (e?e+' ':''); }
function catColor(cat, fallback){ return (config.colors && config.colors[cat]) || fallback; }

// ── Congés / absences : pas de travail planifié sur ces dates ──
function inTimeoff(day){ return (config.timeoff||[]).some(t=>{ try{ const s=new Date(t.start+'T00:00:00'), e=new Date(t.end+'T23:59:59'); return day>=s && day<=e; }catch(_){ return false; } }); }

// ── Inférence du créneau d'après le titre (matin/soir/sport…) → [hDébut,hFin,maxMin] ──
function inferWindow(title){
  const t=(title||'').toLowerCase(); const has=(...w)=>w.some(x=>t.includes(x));
  if(has('réveil','reveil','wake up')) return [5,9,30];
  if(has('morning routine','routine du matin','routine matinale','matinale')) return [5,10,120];
  if(has('petit-déj','petit dej','petit-dejeuner','breakfast')) return [6,10,60];
  if(has('matin','morning')) return [6,12,180];
  if(has('déjeuner','dejeuner','lunch','midi')) return [11,14,90];
  if(has('après-midi','apres-midi','afternoon')) return [13,18,240];
  if(has('dîner','diner','dinner')) return [18,22,90];
  if(has('coucher','bedtime','routine du soir','évening routine')) return [20,23,60];
  if(has('soir','evening','nuit','night')) return [18,23,180];
  if(has('sport','gym','workout','muscu','fitness','training','entraînement','entrainement','course','running','jogging','run')) return [6,21,120];
  if(has('méditation','meditation','yoga','stretch','étirement')) return [6,22,60];
  if(has('lecture','reading','lire')) return [7,23,90];
  if(has('deep work','travail profond','concentration','focus')) return [8,18,180];
  if(has('réunion','reunion','meeting','call','rdv','rendez-vous')) return [8,19,120];
  return null;
}
function overlaps(s,e,events,ignoreId){ return (events||[]).some(ev=>{ if(ignoreId&&ev.id===ignoreId) return false; const es=ev.start?.dateTime?new Date(ev.start.dateTime):null; const ee=ev.end?.dateTime?new Date(ev.end.dateTime):null; if(!es||!ee) return false; return e>es && s<ee; }); }
// Place un événement fixe sans chevauchement, en respectant la fenêtre déduite du titre
function placeNoOverlap(startISO, endISO, events, win){
  let s=new Date(startISO), e=new Date(endISO); let dur=Math.max(15,(e-s)/60000);
  if(win){ const [h0,h1,maxM]=win; if(maxM && dur>maxM) dur=maxM;
    if(s.getHours()<h0){ s.setHours(h0, s.getMinutes(),0,0); }
    if(s.getHours()>=h1){ s.setHours(h0,0,0,0); } // ramène en début de fenêtre
    e=new Date(s.getTime()+dur*60000);
  }
  if(!overlaps(s,e,events)) return { start:isoLocal(s), end:isoLocal(e), shifted:(isoLocal(s)!==startISO) };
  let cur=new Date(s); const limit=new Date(s.getTime()+14*86400000);
  while(cur<limit){
    if(win){ const h=cur.getHours(); if(h<win[0]){ cur.setHours(win[0],0,0,0); continue; } if(h>=win[1]){ cur.setDate(cur.getDate()+1); cur.setHours(win[0],0,0,0); continue; } }
    const ce=new Date(cur.getTime()+dur*60000);
    if(win && (ce.getHours()>win[1] || (ce.getHours()===win[1]&&ce.getMinutes()>0))){ cur.setDate(cur.getDate()+1); cur.setHours(win[0],0,0,0); continue; }
    if(!overlaps(cur,ce,events)) return { start:isoLocal(cur), end:isoLocal(ce), shifted:true };
    cur=new Date(cur.getTime()+15*60000);
  }
  return { start:isoLocal(s), end:isoLocal(e), conflict:true };
}

// Créneaux libres d'un jour dans [h0,h1] (≥ minDur), hors passé et hors "busy"
function freeIn(day,h0,h1,busy,minDur){
  const dS=new Date(day); dS.setHours(h0,0,0,0);
  const dE=new Date(day); dE.setHours(h1,0,0,0);
  const now=new Date();
  let lo=dS; if(dS<now) lo=roundUp5(now); if(lo>=dE) return [];
  const within=busy.filter(b=>b.end>lo && b.start<dE)
    .map(b=>({start:new Date(Math.max(b.start.getTime(),lo.getTime())),end:new Date(Math.min(b.end.getTime(),dE.getTime()))}))
    .sort((a,b)=>a.start-b.start);
  const slots=[]; let cur=new Date(lo);
  for(const b of within){ if(cur<b.start){ const d=(b.start-cur)/60000; if(d>=minDur) slots.push({start:new Date(cur),end:new Date(b.start),duration:d}); } if(b.end>cur) cur=new Date(b.end); }
  if(cur<dE){ const d=(dE-cur)/60000; if(d>=minDur) slots.push({start:new Date(cur),end:new Date(dE),duration:d}); }
  return slots;
}

async function createManaged(b){
  return createEvent({
    title:b.title, start:isoLocal(b.start), end:isoLocal(b.end), colorId:b.colorId, description:'TimeFlow',
    location:b.location||undefined,
    transparency: b.visibility==='free' ? 'transparent' : undefined,
    extendedProperties:{ private:{ tfManaged:'1', tfKind:b.kind, tfRef:String(b.ref||'') } }
  });
}

// Placement d'une habitude : timesPerWeek occurrences/semaine, jour idéal puis heure idéale
function placeHabit(h, busy, t0, t1, created){
  const elig=(h.idealDays||h.days||[]).map(d=>DAY_MAP[String(d).toLowerCase()]).filter(x=>x!=null);
  if(!elig.length) return 0;
  const ideal=h.idealDay?DAY_MAP[String(h.idealDay).toLowerCase()]:null;
  const target=h.maxDur||h.duration||60;
  const minDur=Math.min(h.minDur||target, target);
  const hType=h.hoursType||'personal';
  const [ih,im]=String(h.idealTime||(h.preferredStart!=null?pad2(h.preferredStart)+':00':'18:00')).split(':').map(Number);
  const perWeek=h.timesPerWeek||elig.length||1;
  const hStart=h.startDate? new Date(h.startDate+'T00:00:00') : null;
  const hEnd=h.endDate? new Date(h.endDate+'T23:59:59') : null;
  let weekStart=new Date(t0); const dow=weekStart.getDay(); weekStart.setDate(weekStart.getDate()-((dow+6)%7)); weekStart.setHours(0,0,0,0);
  let total=0;
  while(weekStart<t1){
    let dayList=[];
    for(let i=0;i<7;i++){ const day=new Date(weekStart); day.setDate(weekStart.getDate()+i); day.setHours(0,0,0,0);
      if(day<startOfToday()||day>t1) continue;
      if(hStart && day<hStart) continue; if(hEnd && day>hEnd) continue;
      const wd=day.getDay(); if(!elig.includes(wd)) continue; if(blockedDay(dayKey(wd))) continue;
      if(hType!=='personal' && inTimeoff(day)) continue;
      if(!dayHours(hType, wd)) continue;
      dayList.push(day);
    }
    if(ideal!=null) dayList.sort((a,b)=>(b.getDay()===ideal)-(a.getDay()===ideal));
    let placedWeek=0;
    for(const day of dayList){ if(placedWeek>=perWeek) break;
      const win=dayHours(hType, day.getDay()); if(!win) continue; const [h0,h1]=win;
      const slots=freeIn(day,h0,h1,busy,minDur); if(!slots.length) continue;
      const idealStart=new Date(day); idealStart.setHours(ih,im||0,0,0);
      let best=null;
      for(const s of slots){
        let start;
        if(idealStart>=s.start && new Date(idealStart.getTime()+target*60000)<=s.end) start=idealStart;
        else if(new Date(s.start.getTime()+target*60000)<=s.end) start=new Date(s.start);
        else if(s.duration>=minDur) start=new Date(s.start);
        else continue;
        const dist=Math.abs(start-idealStart);
        if(!best||dist<best.dist) best={start, slotEnd:s.end, dist};
      }
      if(!best) continue;
      const len=Math.min(target, (best.slotEnd-best.start)/60000); if(len<minDur) continue;
      const end=new Date(best.start.getTime()+len*60000);
      const col=h.color || catColor(hType==='personal'?'personal':'work','6');
      created.push({kind:'habit', ref:h.id, title:`${emo(h.emoji||'🔁')}${h.name}`, start:best.start, end, colorId:col, visibility:h.visibility, location:h.location});
      busy.push({start:best.start, end:new Date(end.getTime()+gapMin()*60000)});
      placedWeek++; total++;
    }
    weekStart=new Date(weekStart); weekStart.setDate(weekStart.getDate()+7);
  }
  return total;
}

// Placement d'une tâche : découpage min/max, plafond/jour, avant l'échéance, après "start"
function placeTask(t, busy, horizonEnd, created){
  const total=t.duration||60; let remaining=total;
  const split=t.splitUp!==false;
  const minC=split?Math.max(15,t.minChunk||30):total;
  const maxC=split?Math.max(minC,t.maxChunk||120):total;
  const maxPerDay=Math.max(maxC, t.maxPerDay||config.task_max_per_day||240);
  const hType=t.hoursType||'work';
  const deadline=t.deadline? new Date(String(t.deadline).length<=10? t.deadline+'T23:59:59': t.deadline) : horizonEnd;
  const startAfter=t.scheduleAfter? new Date(t.scheduleAfter) : new Date();
  const rank=prioRank(t.priority);
  const chunks=[];
  for(let i=0;i<21 && remaining>0;i++){
    const day=startOfToday(); day.setDate(day.getDate()+i);
    if(day>deadline) break;
    if(blockedDay(dayKey(day.getDay()))) continue;
    if(hType!=='personal' && inTimeoff(day)) continue;
    const win=dayHours(hType, day.getDay()); if(!win) continue; const [h0,h1]=win;
    let perDay=0, guard=0;
    while(remaining>0 && perDay<maxPerDay && guard++<10){
      const want=Math.min(minC, remaining);
      const slots=freeIn(day,h0,h1,busy,want).filter(s=>s.end>startAfter); if(!slots.length) break;
      const s=slots[0];
      const start=s.start<startAfter? new Date(startAfter): new Date(s.start);
      const avail=(s.end-start)/60000; if(avail<want) break;
      const chunk=Math.min(maxC, remaining, avail, maxPerDay-perDay); if(chunk<want) break;
      const end=new Date(start.getTime()+chunk*60000);
      chunks.push({start,end});
      busy.push({start, end:new Date(end.getTime()+gapMin()*60000)});
      remaining-=chunk; perDay+=chunk;
      if(!split) break;
    }
    if(!split && chunks.length) break;
  }
  const n=chunks.length;
  chunks.forEach((c,idx)=>{
    const dot = config.emoji_prefix===false ? '' : (t.emoji?t.emoji+' ':PRIO_DOT[rank]+' ');
    const label=n>1? `${dot}${t.title} (${idx+1}/${n})` : `${dot}${t.title}`;
    const col=t.color || catColor(hType==='personal'?'personal':'work', PRIO_COLOR[rank]);
    created.push({kind:'task', ref:t.id, title:label, start:c.start, end:c.end, colorId:col});
  });
  return { n, placed: total-remaining, missing: remaining };
}

// Ordonnancement des tâches type Reclaim : Up Next → à risque (échéance) → priorité + échéance
function businessDaysUntil(deadline){
  const today=startOfToday(); let d=new Date(today), n=0, guard=0;
  while(d<=deadline && guard++<120){ const wd=d.getDay(); if(dayHours('work',wd) && !blockedDay(dayKey(wd))) n++; d.setDate(d.getDate()+1); }
  return Math.max(1,n);
}
function orderTasks(list, horizonEnd){
  const meta=list.map(t=>{
    const total=t.duration||60;
    const maxC=(t.splitUp!==false)?Math.max(15,t.maxChunk||config.task_defaults?.max_chunk||120):total;
    const maxPerDay=Math.max(maxC, t.maxPerDay||config.task_max_per_day||240);
    const deadline=t.deadline? new Date(String(t.deadline).length<=10? t.deadline+'T23:59:59': t.deadline) : horizonEnd;
    const daysNeeded=Math.ceil(total/maxPerDay);
    const slack=businessDaysUntil(deadline)-daysNeeded;
    return { t, deadline, slack, upNext:!!t.upNext, ord:(t.upNextOrder??0) };
  });
  const upN = meta.filter(x=>x.upNext).sort((a,b)=>a.ord-b.ord);
  const rest= meta.filter(x=>!x.upNext);
  const risk= rest.filter(x=>x.slack<=1).sort((a,b)=> a.deadline-b.deadline || prioRank(a.t.priority)-prioRank(b.t.priority));
  const norm= rest.filter(x=>x.slack>1 ).sort((a,b)=> prioRank(a.t.priority)-prioRank(b.t.priority) || a.deadline-b.deadline);
  return [...upN, ...risk, ...norm].map(x=>x.t);
}

// Focus proactif (si objectif hebdo défini) : remplit les trous des jours ouvrés
function placeFocus(busy, t0, t1, created){
  const targetMin=(config.focus_weekly_target||0)*60; if(targetMin<=0) return 0;
  const dur=config.focus_duration||120; const maxDay=config.focus_max_per_day||180;
  let weekStart=new Date(t0); const dow=weekStart.getDay(); weekStart.setDate(weekStart.getDate()-((dow+6)%7)); weekStart.setHours(0,0,0,0);
  let total=0;
  while(weekStart<t1){
    let weekMin=0;
    for(let i=0;i<7;i++){ if(weekMin>=targetMin) break;
      const day=new Date(weekStart); day.setDate(weekStart.getDate()+i); day.setHours(0,0,0,0);
      if(day<startOfToday()||day>t1) continue; if(blockedDay(dayKey(day.getDay()))) continue;
      if(inTimeoff(day)) continue;
      const win=dayHours('work', day.getDay()); if(!win) continue; const [h0,h1]=win;
      let dayMin=0, guard=0;
      while(weekMin<targetMin && dayMin<maxDay && guard++<4){
        const need=Math.min(dur, targetMin-weekMin, maxDay-dayMin);
        const minSlot = config.focus_mode==='reactive' ? Math.min(dur, need) : Math.min(need,30);
        const slots=freeIn(day,h0,h1,busy,minSlot); if(!slots.length) break;
        const s=slots.sort((a,b)=>b.duration-a.duration)[0];
        const len=Math.min(dur, s.duration, targetMin-weekMin, maxDay-dayMin); if(len<30) break;
        const end=new Date(s.start.getTime()+len*60000);
        created.push({kind:'focus', ref:'', title:`${emo('🎯')}Focus`, start:new Date(s.start), end, colorId:catColor('focus','2')});
        busy.push({start:new Date(s.start), end:new Date(end.getTime()+gapMin()*60000)});
        weekMin+=len; dayMin+=len; total++;
      }
    }
    weekStart=new Date(weekStart); weekStart.setDate(weekStart.getDate()+7);
  }
  return total;
}
function placeFocusDay(day, busy, created){
  const win=dayHours('work', day.getDay()); if(!win) return 0; const [h0,h1]=win; const dur=config.focus_duration||120;
  const slots=freeIn(day,h0,h1,busy,Math.min(dur,30)); if(!slots.length) return 0;
  const s=slots.sort((a,b)=>b.duration-a.duration)[0]; const len=Math.min(dur,s.duration);
  const end=new Date(s.start.getTime()+len*60000);
  created.push({kind:'focus',ref:'',title:`${emo('🎯')}Focus`,start:new Date(s.start),end,colorId:catColor('focus','2')});
  busy.push({start:new Date(s.start),end}); return 1;
}

// ─── SOLVEUR PRINCIPAL ───
async function optimize(opts={}){
  if(!tokens) return {created:0, error:'non connecté'};
  const only = opts.only||'all';
  const days = opts.days || config.horizon_days || 14;
  const now=new Date();
  const t0=new Date(now); t0.setHours(0,0,0,0);
  const t1=new Date(t0); t1.setDate(t0.getDate()+days); t1.setHours(23,59,59,0);
  try{
    let events = await getEvents(t0.toISOString(), t1.toISOString());
    // 1) Efface les blocs gérés FUTURS, non verrouillés, du type concerné
    if(opts.wipe!==false){
      const wipe = events.filter(e=> isManaged(e) && !isLocked(e) && e.start?.dateTime
        && (only==='all' || tfKindOf(e)===only)
        && new Date(e.end.dateTime) > now);
      for(const e of wipe){ try{ await deleteEvent(e.id); }catch{} }
      const wiped=new Set(wipe.map(e=>e.id));
      events = events.filter(e=>!wiped.has(e.id));
      if(only==='all'||only==='task') tasks.forEach(t=>{ if((t.eventIds||[t.eventId]).some(id=>wiped.has(id))){ t.scheduled=false; t.eventIds=[]; t.eventId=null; } });
    }
    // 2) "busy" immuable = événements réels + blocs verrouillés
    const busy = events.filter(e=> e.start?.dateTime && (!isManaged(e) || isLocked(e)))
      .map(e=>({start:new Date(e.start.dateTime), end:new Date(e.end.dateTime)}));
    // 3) Placement : habitudes (par priorité, défense stricte d'abord) puis tâches (par urgence)
    const created=[]; const risks=[];
    const habitsActive = habits.filter(h=>h.active!==false && !snoozed(h));
    const tasksPending = tasks.filter(t=>t.active!==false && !t.scheduled && !snoozed(t) && !t.locked);
    if(only==='all'||only==='habit'){
      for(let p=0;p<4;p++){
        habitsActive.filter(h=>prioRank(h.priority)===p)
          .sort((a,b)=>((b.timeDefense==='aggressive')?1:0)-((a.timeDefense==='aggressive')?1:0))
          .forEach(h=>placeHabit(h,busy,t0,t1,created));
      }
    }
    if(only==='all'||only==='task'){
      for(const t of orderTasks(tasksPending, t1)){
        const r=placeTask(t,busy,t1,created);
        if(r && r.missing>0) risks.push({ id:t.id, title:t.title, missing:r.missing, priority:t.priority, deadline:t.deadline||null });
      }
    }
    if((only==='all'||only==='focus')) placeFocus(busy,t0,t1,created);
    // 4) Écriture dans Google Agenda + association tâche→eventIds
    const idsByTask={}; const todayEnd=new Date(t0); todayEnd.setHours(23,59,59,0); let lockedAny=false;
    for(const b of created){ try{ const ev=await createManaged(b);
      if(b.kind==='task') (idsByTask[b.ref]=idsByTask[b.ref]||[]).push(ev.id);
      if(config.auto_lock && ev.id && new Date(b.start)<=todayEnd){ locks.add(ev.id); lockedAny=true; }
    }catch(e){ console.error('create',e.message); } }
    if(lockedAny) saveLocks();
    if(only==='all'||only==='task'){ Object.entries(idsByTask).forEach(([rid,ids])=>{ const t=tasks.find(x=>x.id===rid); if(t){ t.scheduled=true; t.eventIds=ids; t.eventId=ids[0]; } }); saveTasks(); }
    return {created:created.length, risks};
  }catch(e){ console.error('optimize:', e.message); return {created:0, error:e.message}; }
}

// ─── Fonctions historiques (déléguées au solveur) ───
async function autoTimeBlock(targetDate){
  if(!tokens||!config.auto_schedule) return 0;
  try{
    const date=new Date(targetDate); date.setHours(0,0,0,0); const end=new Date(date); end.setHours(23,59,59,0);
    const events=await getEvents(date.toISOString(), end.toISOString());
    if(events.some(e=>tfKindOf(e)==='focus')) return 0;
    const busy=events.filter(e=>e.start?.dateTime && (!isManaged(e)||isLocked(e))).map(e=>({start:new Date(e.start.dateTime),end:new Date(e.end.dateTime)}));
    const created=[]; placeFocusDay(date, busy, created);
    for(const b of created){ try{ await createManaged(b);}catch{} }
    return created.length;
  }catch(e){ console.error('TimeBlock:',e.message); return 0; }
}
async function scheduleHabits(){ return (await optimize({only:'habit', days:8})).created; }
async function scheduleTasks(){ return (await optimize({only:'task'})).created; }

async function addBuffers(){
  if(!tokens) return 0;
  const brk=config.buffers?.task_habit_break||0, travel=config.buffers?.travel_time||0, decomp=config.buffers?.decompression||0;
  if(!brk && !travel && !decomp && !config.buffer_minutes) return 0;
  let n=0;
  try{
    const t0=new Date(); t0.setHours(0,0,0,0); const t1=new Date(t0); t1.setDate(t0.getDate()+(config.horizon_days||14));
    const events=await getEvents(t0.toISOString(), t1.toISOString());
    const timed=events.filter(e=>e.start?.dateTime && tfKindOf(e)!=='buffer' && !e.summary?.includes('🚗') && !e.summary?.includes('😌'));
    const mkBuf=async(title,colorCat,start,end)=>{ await createEvent({title, start:isoLocal(start), end:isoLocal(end), colorId:catColor(colorCat,'8'), transparency:'transparent', extendedProperties:{private:{tfManaged:'1',tfKind:'buffer'}}}); n++; };
    const occupied=timed.map(e=>({s:new Date(e.start.dateTime),e:new Date(e.end.dateTime)}));
    const free=(s,e)=>!occupied.some(o=>e>o.s && s<o.e);
    // Travel + décompression autour des événements
    for(const e of timed){
      const s=new Date(e.start.dateTime), en=new Date(e.end.dateTime);
      const isMeeting=!isManaged(e);
      if(travel && e.location){
        const b1s=new Date(s.getTime()-travel*60000); if(free(b1s,s)) await mkBuf(emo('🚗')+'Trajet','travel_breaks',b1s,s);
        const b2e=new Date(en.getTime()+travel*60000); if(free(en,b2e)) await mkBuf(emo('🚗')+'Trajet','travel_breaks',en,b2e);
      }
      if(decomp && isMeeting){
        const de=new Date(en.getTime()+decomp*60000); if(free(en,de)) await mkBuf(emo('😌')+'Décompression','travel_breaks',en,de);
      }
    }
    // Pauses entre blocs trop rapprochés (Task & Habit breaks)
    const minGap=brk||config.buffer_minutes||0;
    if(minGap){
      const days={};
      timed.forEach(e=>{ const k=new Date(e.start.dateTime).toDateString(); (days[k]=days[k]||[]).push(e); });
      for(const k of Object.keys(days)){
        const sorted=days[k].sort((a,b)=>new Date(a.start.dateTime)-new Date(b.start.dateTime));
        for(let i=0;i<sorted.length-1;i++){
          const g=(new Date(sorted[i+1].start.dateTime)-new Date(sorted[i].end.dateTime))/60000;
          if(g>0 && g<minGap){ await mkBuf(emo('⏸️')+'Pause','travel_breaks',new Date(sorted[i].end.dateTime),new Date(sorted[i+1].start.dateTime)); }
        }
      }
    }
  }catch(e){ console.error('Buffers:',e.message); }
  return n;
}

// ─── REVUE HEBDO ───
async function weeklyReview() {
  if (!tokens) return;
  try {
    const events = await getEvents(new Date(Date.now()-7*86400000).toISOString(), new Date().toISOString());
    let fm=0, mm=0, hc=0;
    for (const e of events) {
      if (!e.start?.dateTime) continue;
      const dur = (new Date(e.end?.dateTime)-new Date(e.start?.dateTime))/60000;
      if (tfKindOf(e)==='focus') fm+=dur;
      else if (habits.some(h=>e.summary?.includes(h.name))) hc++;
      else if (tfKindOf(e)!=='buffer') mm+=dur;
    }
    stats = { focusHours:Math.round(fm/60*10)/10, meetingHours:Math.round(mm/60*10)/10, habitsCompleted:hc, streak:(stats.streak||0)+(hc>0?1:0), lastReview:new Date().toISOString() };
    saveStats();
    const weekOf = new Date(Date.now()-7*86400000).toISOString().split('T')[0];
    memory.weekHistory = memory.weekHistory.filter(w=>w.weekOf!==weekOf);
    memory.weekHistory.push({ weekOf, summary:`Focus: ${stats.focusHours}h, Réunions: ${stats.meetingHours}h, Habitudes: ${hc} complétées`, created:new Date().toISOString() });
    if (memory.weekHistory.length>8) memory.weekHistory = memory.weekHistory.slice(-8);
    saveMemory();
  } catch(e){ console.error('Review:', e.message); }
}

// ─── PLANIFIER (délégué au solveur) ───
async function planWeek(targetMonday){ return (await optimize({days:7})).created; }
async function planTwoWeeks(){ const r=await optimize({days:config.horizon_days||14}); await weeklyReview(); return r.created; }

// ─── DÉTECTION CHANGEMENTS + REPLAN ───
async function detectCalendarChanges() {
  if (!tokens) return;
  try {
    const now=new Date(), tw=new Date(now.getTime()+14*86400000);
    const events = await getEvents(now.toISOString(), tw.toISOString());
    const userEvents = events.filter(e=>!isManaged(e));
    const hash = buildEventsHash(userEvents);
    if (hash !== lastCalendarHash && lastCalendarHash !== '') {
      if (replanDebounce) clearTimeout(replanDebounce);
      replanDebounce = setTimeout(async()=>{ await smartReplan(); replanDebounce=null; }, 30000);
    }
    lastCalendarHash = hash;
  } catch(e){}
}

async function smartReplan(){ if(!tokens) return; await optimize({days:config.horizon_days||14}); }

// ─── SCHEDULER (déclencheurs temporels) ───
function startScheduler() {
  setInterval(async()=>{
    if (!tokens) return;
    const now=new Date(), h=now.getHours(), m=now.getMinutes(), d=now.getDay();
    if (h===7 && m===0 && config.auto_schedule){ const t=new Date(); t.setDate(t.getDate()+1); await autoTimeBlock(t); }
    if (d===0 && h===20 && m===0) await planTwoWeeks();
    if (d===0 && h===20 && m===30) await weeklyReview();
  }, 60000);
  setInterval(detectCalendarChanges, 5*60*1000);
  setTimeout(async()=>{ if (tokens){ try{
    const now=new Date(), tw=new Date(now.getTime()+14*86400000);
    const events = await getEvents(now.toISOString(), tw.toISOString());
    lastCalendarHash = buildEventsHash(events.filter(e=>!isManaged(e)));
  }catch{} } }, 10000);
}
startScheduler();

// ─── HTTP ───
function cors(res){ res.setHeader('Access-Control-Allow-Origin','*'); res.setHeader('Access-Control-Allow-Methods','GET,POST,PATCH,DELETE,OPTIONS'); res.setHeader('Access-Control-Allow-Headers','Content-Type'); }
function j(res,data,status=200){ cors(res); res.writeHead(status,{'Content-Type':'application/json'}); res.end(JSON.stringify(data)); }
function h(res,content){ cors(res); res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}); res.end(content); }
function body(req){ return new Promise(r=>{ let b=''; req.on('data',d=>b+=d); req.on('end',()=>{ try{r(JSON.parse(b));}catch{r({});} }); }); }

const LOGIN_PAGE = creds => `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TimeFlow</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Pro Display","Helvetica Neue","Segoe UI",system-ui,sans-serif;background:#f5f5f7;color:#1d1d1f;display:flex;align-items:center;justify-content:center;height:100vh;-webkit-font-smoothing:antialiased}
.c{background:#fff;border-radius:16px;padding:44px 40px;width:380px;text-align:center;border:1px solid #e6e6e9;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.logo{width:56px;height:56px;border-radius:14px;background:#1d1d1f;color:#fff;margin:0 auto 22px;display:flex;align-items:center;justify-content:center}
h1{font-size:24px;font-weight:600;letter-spacing:-.02em;margin-bottom:8px}p{color:#86868b;font-size:14px;margin-bottom:28px;line-height:1.5}
.gbtn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:13px;background:#fff;border:1px solid #d2d2d7;border-radius:10px;color:#1d1d1f;font-size:15px;cursor:pointer;font-weight:500;text-decoration:none;transition:.15s ease}.gbtn:hover{background:#f5f5f7;border-color:#b8b8be}
.or{margin:18px 0 12px;color:#aeaeb2;font-size:12px}.link{color:#0071e3;font-size:13px;cursor:pointer;background:none;border:none}
.hint{margin-top:16px;color:#aeaeb2;font-size:12px;line-height:1.5}.adv-toggle{display:inline-block;margin-top:18px;color:#86868b;font-size:12.5px}.adv-toggle:hover{color:#0071e3}
input{width:100%;padding:11px 13px;background:#f5f5f7;border:1px solid #d2d2d7;border-radius:10px;color:#1d1d1f;font-size:13px;margin-bottom:9px;font-family:ui-monospace,monospace}input:focus{outline:none;border-color:#0071e3;background:#fff;box-shadow:0 0 0 3px rgba(0,113,227,.12)}
.sbtn{width:100%;padding:12px;background:#0071e3;border:none;border-radius:10px;color:#fff;font-size:15px;cursor:pointer;font-weight:500;transition:background .15s ease}.sbtn:hover{background:#0064c8}</style></head>
<body><div class="c"><div class="logo"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="16" rx="3"/><path d="M3 9h18M8 2.5v4M16 2.5v4"/></svg></div><h1>TimeFlow</h1>
${creds
  ? `<p>Connecte ton agenda Google et laisse TimeFlow organiser ta semaine automatiquement.</p><a class="gbtn" href="/auth"><svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>Continuer avec Google</a>
  <div class="hint">TimeFlow accède uniquement à ton Google Agenda et fonctionne en local sur ton ordinateur.</div>
  <button class="link adv-toggle" onclick="document.getElementById('adv').style.display='block';this.style.display='none'">Utiliser d'autres identifiants Google</button>
  <div id="adv" style="display:none;margin-top:14px;text-align:left"><input id="cid" placeholder="Client ID"><input id="cs" type="password" placeholder="Client Secret"><button class="sbtn" onclick="save()">Enregistrer et connecter</button></div>`
  : `<p>Pour démarrer, renseigne les identifiants OAuth de ton projet Google Cloud (API Calendar activée).</p><div style="text-align:left"><input id="cid" placeholder="Client ID (…apps.googleusercontent.com)"><input id="cs" type="password" placeholder="Client Secret (GOCSPX-…)"><button class="sbtn" onclick="save()">Connecter</button></div><div class="hint">Astuce : renseigne ces identifiants dans server.js pour afficher directement le bouton « Continuer avec Google ».</div>`}
</div><script>function save(){fetch('/setup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:document.getElementById('cid').value,client_secret:document.getElementById('cs').value})}).then(r=>r.json()).then(d=>location.href=d.auth_url);}</script></body></html>`;

const server = http.createServer(async(req,res)=>{
  const url = new URL(req.url, `http://localhost:${PORT}`);
  if (req.method==='OPTIONS'){ cors(res); res.writeHead(204); res.end(); return; }

  if (url.pathname==='/auth'){ if (hasCreds()){ res.writeHead(302,{Location:getAuthUrl()}); res.end(); } else { res.writeHead(302,{Location:'/'}); res.end(); } return; }

  if (url.pathname==='/' && !tokens){ h(res, LOGIN_PAGE(hasCreds())); return; }

  if (url.pathname==='/setup' && req.method==='POST'){
    const b = await body(req); config.client_id=b.client_id; config.client_secret=b.client_secret; saveConfig();
    j(res,{auth_url:getAuthUrl()}); return;
  }

  if (url.pathname==='/oauth/callback'){
    const code = url.searchParams.get('code');
    try {
      const t = await oauthPost({ code, client_id:clientId(), client_secret:clientSecret(), redirect_uri:REDIRECT_URI, grant_type:'authorization_code' });
      if (!t.access_token) throw new Error(t.error_description||'Échec OAuth');
      tokens = {...t, expiry_date:Date.now()+(t.expires_in*1000)}; fs.writeFileSync(TOKEN_FILE, JSON.stringify(tokens));
      h(res, `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue","Segoe UI",system-ui,sans-serif;background:#f5f5f7;color:#1d1d1f;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;-webkit-font-smoothing:antialiased}.card{background:#fff;border:1px solid #e6e6e9;border-radius:16px;padding:40px 44px;box-shadow:0 1px 3px rgba(0,0,0,.04)}.ok{width:52px;height:52px;border-radius:50%;background:#34c759;color:#fff;margin:0 auto 18px;display:flex;align-items:center;justify-content:center}h2{font-weight:600;font-size:20px;letter-spacing:-.02em;margin:0 0 6px}p{color:#6e6e73;font-size:14px;margin:0}a{color:#0071e3;text-decoration:none}</style></head><body><div class="card"><div class="ok"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4 4 10-10.5"/></svg></div><h2>Google Calendar connecté</h2><p>Ouverture de <a href="http://localhost:${PORT}/app">l'application</a>…</p></div><script>setTimeout(()=>location.href='/app',1200)</script></body></html>`);
    } catch(e){ j(res,{error:e.message},500); }
    return;
  }

  if (url.pathname==='/app' || (url.pathname==='/' && tokens)){
    const ap = path.join(__dirname,'app.html');
    if (fs.existsSync(ap)) h(res, fs.readFileSync(ap,'utf8')); else j(res,{error:'app.html introuvable'},404);
    return;
  }

  // ── API ──
  if (url.pathname==='/api/status'){ j(res,{authenticated:!!tokens, config}); return; }
  if (url.pathname==='/api/config' && req.method==='POST'){ const b=await body(req);
      const NEST=['profile','working_hours','personal_hours','meeting_hours','buffers','colors','task_defaults','notif'];
      for(const k of NEST) if(b[k] && typeof b[k]==='object') b[k]={...config[k],...b[k]};
      config={...config,...b}; saveConfig(); j(res,{success:true,config}); return; }
  if (url.pathname==='/api/logout' && req.method==='POST'){ tokens=null; if(fs.existsSync(TOKEN_FILE)) fs.unlinkSync(TOKEN_FILE); j(res,{success:true}); return; }

  // Compte Google connecté (email + nom via l'agenda principal)
  if (url.pathname==='/api/me'){
    if(!tokens){ j(res,{connected:false}); return; }
    try{ const r=await calReq('GET','/calendar/v3/calendars/primary');
      const list=await calReq('GET','/calendar/v3/users/me/calendarList');
      const cals=(list.data.items||[]).map(c=>({id:c.id,summary:c.summary,primary:!!c.primary,role:c.accessRole}));
      j(res,{connected:true, email:r.data.id, name:r.data.summary, timezone:r.data.timeZone, calendars:cals}); }
    catch(e){ j(res,{connected:true, error:e.message}); } return;
  }
  // Test connexion Ollama
  if (url.pathname==='/api/ollama/test'){
    try{ const u=new URL(config.ollama_url||'http://127.0.0.1:11434');
      const tags=await new Promise((resolve,reject)=>{ const rq=http.request({hostname:u.hostname,port:u.port||11434,path:'/api/tags',method:'GET'},rs=>{let d='';rs.on('data',c=>d+=c);rs.on('end',()=>{try{resolve(JSON.parse(d))}catch(e){reject(e)}})}); rq.on('error',reject); rq.setTimeout(2500,()=>{rq.destroy(new Error('timeout'))}); rq.end(); });
      const models=(tags.models||[]).map(m=>m.name);
      j(res,{ok:true, models, hasModel:models.some(m=>m.startsWith((config.model||'').split(':')[0]))}); }
    catch(e){ j(res,{ok:false, error:e.message}); } return;
  }
  // Export / Import / Reset des données
  if (url.pathname==='/api/export'){ j(res,{ exportedAt:new Date().toISOString(), config, habits, tasks, memory }); return; }
  if (url.pathname==='/api/import' && req.method==='POST'){ const b=await body(req);
      if(Array.isArray(b.habits)){ habits=b.habits; saveHabits(); }
      if(Array.isArray(b.tasks)){ tasks=b.tasks; saveTasks(); }
      if(b.memory && typeof b.memory==='object'){ memory={...DEFAULT_MEMORY,...b.memory}; saveMemory(); }
      if(b.config && typeof b.config==='object'){ const c={...b.config}; delete c.client_id; delete c.client_secret; config={...config,...c}; saveConfig(); }
      j(res,{success:true, habits:habits.length, tasks:tasks.length}); return; }
  if (url.pathname==='/api/reset' && req.method==='POST'){ const b=await body(req);
      if(b.habits!==false){ habits=[]; saveHabits(); }
      if(b.tasks!==false){ tasks=[]; saveTasks(); }
      if(b.memory){ memory={...DEFAULT_MEMORY}; saveMemory(); }
      j(res,{success:true}); return; }

  if (url.pathname==='/api/events' && req.method==='GET'){
    try { const items = await getEvents(url.searchParams.get('timeMin'), url.searchParams.get('timeMax'));
      j(res, items.map(e=>({id:e.id,title:e.summary||'Sans titre',start:e.start?.dateTime||e.start?.date,end:e.end?.dateTime||e.end?.date,colorId:e.colorId,allDay:!e.start?.dateTime,managed:isManaged(e),locked:isLocked(e),kind:tfKindOf(e)}))); }
    catch(e){ j(res,{error:e.message},500); } return;
  }
  if (url.pathname==='/api/events' && req.method==='POST'){ try{ const b=await body(req);
      if(b.start && b.end && !b.allDay){ const t0=new Date(b.start); t0.setHours(0,0,0,0); const t1=new Date(t0); t1.setDate(t0.getDate()+1);
        let evs=[]; try{ evs=await getEvents(t0.toISOString(), t1.toISOString()); }catch(_){}
        const slot=placeNoOverlap(b.start, b.end, evs, null); b.start=slot.start; b.end=slot.end; }
      const ev=await createEvent(b); if(b.lock&&ev.id){ locks.add(ev.id); saveLocks(); } j(res,{id:ev.id,title:ev.summary}); }catch(e){ j(res,{error:e.message},500); } return; }
  if (url.pathname.startsWith('/api/events/') && req.method==='PATCH'){ try{ const id=url.pathname.split('/')[3]; const b=await body(req);
      const ev=await updateEvent(id,b);
      if(b.lock){ locks.add(id); saveLocks(); } if(b.unlock){ locks.delete(id); saveLocks(); }
      j(res,{id:ev.id,title:ev.summary,locked:locks.has(id)}); }catch(e){ j(res,{error:e.message},500); } return; }
  if (url.pathname.startsWith('/api/events/') && req.method==='DELETE'){ try{ const id=url.pathname.split('/')[3]; await deleteEvent(id);
      if(locks.has(id)){ locks.delete(id); saveLocks(); }
      let changed=false; tasks.forEach(t=>{ if((t.eventIds||[t.eventId]).includes(id)){ t.eventIds=(t.eventIds||[]).filter(x=>x!==id); if(!t.eventIds.length){ t.scheduled=false; t.eventId=null; } changed=true; } }); if(changed) saveTasks();
      j(res,{success:true}); }catch(e){ j(res,{error:e.message},500); } return; }

  if (url.pathname==='/api/chat' && req.method==='POST'){
    try { const b=await body(req);
      const events = await getEvents(new Date().toISOString(), new Date(Date.now()+7*86400000).toISOString());
      j(res, await processChat(b.message||'', b.history||[], events)); }
    catch(e){ j(res,{error:e.message, response:'Désolé, une erreur est survenue (Ollama est-il lancé ?).'},500); } return;
  }

  if (url.pathname==='/api/memory' && req.method==='GET'){ j(res,memory); return; }
  if (url.pathname==='/api/memory' && req.method==='POST'){
    const b=await body(req); const type=b.type, text=b.text?.trim();
    if (type && text && memory[type]){ if(!memory[type].find(x=>x.text===text)) memory[type].push({id:Date.now()+'',text,addedAt:new Date().toISOString()}); saveMemory(); }
    j(res,memory); return;
  }
  if (url.pathname.startsWith('/api/memory/') && req.method==='DELETE'){
    const p=url.pathname.split('/'); const type=p[3], id=p[4];
    if (memory[type]){ memory[type]=memory[type].filter(x=>x.id!==id); saveMemory(); } j(res,memory); return;
  }

  if (url.pathname==='/api/freeSlots'){
    try { const date=url.searchParams.get('date')?new Date(url.searchParams.get('date')):new Date();
      const de=new Date(date); de.setHours(23,59,0,0);
      const evs=await getEvents(date.toISOString(),de.toISOString());
      const slots=getFreeSlots(evs,date,config.work_start,config.work_end,30);
      j(res,slots.map(s=>({start:s.start.toISOString(),end:s.end.toISOString(),duration:s.duration}))); }
    catch(e){ j(res,{error:e.message},500); } return;
  }

  if (url.pathname==='/api/habits' && req.method==='GET'){ j(res,habits); return; }
  if (url.pathname==='/api/habits' && req.method==='POST'){ const b=await body(req); const ha={id:Date.now()+'',active:true,...b}; habits.push(ha); saveHabits(); await scheduleHabits(); j(res,ha); return; }
  if (url.pathname.startsWith('/api/habits/') && req.method==='DELETE'){ const id=url.pathname.split('/')[3]; habits=habits.filter(x=>x.id!==id); saveHabits(); j(res,{success:true}); return; }
  if (url.pathname.startsWith('/api/habits/') && req.method==='PATCH'){ const id=url.pathname.split('/')[3]; const b=await body(req); habits=habits.map(x=>x.id===id?{...x,...b}:x); saveHabits(); j(res,{success:true}); return; }

  if (url.pathname==='/api/tasks' && req.method==='GET'){ j(res,tasks); return; }
  if (url.pathname==='/api/tasks' && req.method==='POST'){ const b=await body(req); const ta={id:Date.now()+'',active:true,scheduled:false,...b}; tasks.push(ta); saveTasks(); await scheduleTasks(); j(res,ta); return; }
  if (url.pathname.startsWith('/api/tasks/') && req.method==='DELETE'){ const id=url.pathname.split('/')[3]; tasks=tasks.filter(x=>x.id!==id); saveTasks(); j(res,{success:true}); return; }
  if (url.pathname.startsWith('/api/tasks/') && req.method==='PATCH'){ const id=url.pathname.split('/')[3]; const b=await body(req); tasks=tasks.map(x=>x.id===id?{...x,...b}:x); saveTasks(); j(res,{success:true}); return; }

  if (url.pathname==='/api/stats'){ j(res,stats); return; }

  if (url.pathname==='/api/run/optimize' && req.method==='POST'){ const b=await body(req); const r=await optimize({days:b.days||config.horizon_days||14}); await weeklyReview(); j(res,{success:!r.error,created:r.created,error:r.error,risks:r.risks||[]}); return; }
  if (url.pathname==='/api/run/timeblock' && req.method==='POST'){ const t=new Date(); t.setDate(t.getDate()+1); const n=await autoTimeBlock(t); j(res,{success:true,created:n}); return; }
  if (url.pathname==='/api/run/habits'   && req.method==='POST'){ const n=await scheduleHabits(); j(res,{success:true,created:n}); return; }
  if (url.pathname==='/api/run/tasks'    && req.method==='POST'){ const n=await scheduleTasks();  j(res,{success:true,created:n}); return; }
  if (url.pathname==='/api/run/buffers'  && req.method==='POST'){ const n=await addBuffers();     j(res,{success:true,created:n}); return; }
  if (url.pathname==='/api/run/review'   && req.method==='POST'){ await weeklyReview(); j(res,stats); return; }
  if (url.pathname==='/api/run/planweek' && req.method==='POST'){ const n=await planTwoWeeks(); j(res,{success:true,created:n}); return; }
  if (url.pathname==='/api/run/replan'   && req.method==='POST'){ await smartReplan(); j(res,{success:true}); return; }

  res.writeHead(404); res.end('Not found');
});

server.listen(PORT,()=>{
  console.log(`\n⚡ TimeFlow → http://localhost:${PORT}/app`);
  if (!tokens) console.log(`⚠️  Configuration → http://localhost:${PORT}`);
  else console.log(`✅ Google Calendar connecté · Planificateur actif`);
  console.log(`📅 Planning auto : dimanche 20h (2 semaines à l'avance)`);
  console.log(`🔄 Détection des changements : toutes les 5 minutes\n`);
});
